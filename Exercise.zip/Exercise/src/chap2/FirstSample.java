package chap2;

public class FirstSample {
	public static void main(String[] args) {
		double x = 4;
		double y = Math.sqrt(x);
		System.out.println(y);
	}
}
